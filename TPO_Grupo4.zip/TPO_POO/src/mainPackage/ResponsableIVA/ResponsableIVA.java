package mainPackage.ResponsableIVA;

public abstract class ResponsableIVA {
    protected int cuit;

}
