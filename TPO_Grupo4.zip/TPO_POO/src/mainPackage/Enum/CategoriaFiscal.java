package mainPackage.Enum;

public enum CategoriaFiscal {
    Monotributista,
    ResponsableInscripto,

}