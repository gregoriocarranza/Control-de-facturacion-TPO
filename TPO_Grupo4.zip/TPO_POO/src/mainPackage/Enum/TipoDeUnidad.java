package mainPackage.Enum;

public enum TipoDeUnidad {
    UNIDAD,
    PESO,
    HORAS
}
