package mainPackage.ResponsableIVA;
import mainPackage.Enum.TipoDeIva;

public class Monotributista {
    protected TipoDeIva tipoDeIva;

}
