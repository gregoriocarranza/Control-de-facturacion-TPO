package mainPackage.ResponsableIVA;
import mainPackage.Enum.TipoDeIva;

public class responsableInscripto {
    protected TipoDeIva tipoDeIva;

}
