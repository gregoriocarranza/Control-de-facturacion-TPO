package mainPackage.Enum;

public enum RetencionDeImpuestos {
    IVA,
    IIBB,
    GANANCIAS
}